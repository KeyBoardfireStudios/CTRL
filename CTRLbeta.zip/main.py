import sys
import time

# Cross-platform getch
try:
    import msvcrt

    def getch():
        return msvcrt.getch()

except ImportError:
    import tty
    import termios

    def getch():
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = sys.stdin.read(1)
            return ch.encode()
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


text_lines = [""]
mode = "insert"
command = ""
current_file = None
status_msg = ""


def clear_screen():
    print("\033[2J\033[H", end="")


def draw():
    clear_screen()

    print("=== CTRL EDITOR ===\n")

    for line in text_lines:
        print(line)

    print("\n---------------------------")
    print(f"[{status_msg}]")

    if mode == "insert":
        print("-- INSERT MODE --")
    else:
        print(":" + command)


def save_file(filename):
    global current_file, status_msg
    try:
        with open(filename, "w", encoding="utf-8") as f:
            f.write("\n".join(text_lines))
        current_file = filename
        status_msg = f"Saved to {filename}"
    except Exception as e:
        status_msg = f"Save error: {e}"


def open_file(filename):
    global text_lines, current_file, status_msg
    try:
        with open(filename, "r", encoding="utf-8") as f:
            text_lines = f.read().split("\n")
        current_file = filename
        status_msg = f"Opened {filename}"
    except Exception as e:
        status_msg = f"Open error: {e}"


def handle_command(cmd):
    global text_lines, status_msg

    parts = cmd.strip().split()

    if not parts:
        return

    if parts[0] == "q":
        sys.exit()

    elif parts[0] == "c":
        text_lines = [""]
        status_msg = "Cleared text"

    elif parts[0] == "w":
        if len(parts) > 1:
            save_file(parts[1])
        elif current_file:
            save_file(current_file)
        else:
            status_msg = "No filename given!"

    elif parts[0] == "o":
        if len(parts) > 1:
            open_file(parts[1])
        else:
            status_msg = "No filename given!"


if __name__ == "__main__":
    while True:
        draw()

        key = getch()

        # Ctrl+B
        if key == b'\x02':
            if mode == "insert":
                mode = "command"
                command = ""
            else:
                mode = "insert"

        elif mode == "insert":
            if key == b'\r' or key == b'\n':  # Enter
                text_lines.append("")
            elif key == b'\x7f' or key == b'\x08':  # Backspace (Linux/Mac/Win)
                if text_lines[-1]:
                    text_lines[-1] = text_lines[-1][:-1]
            else:
                try:
                    text_lines[-1] += key.decode("utf-8")
                except:
                    pass

        elif mode == "command":
            if key == b'\r' or key == b'\n':
                handle_command(command)
                command = ""
                mode = "insert"

            elif key == b'\x7f' or key == b'\x08':
                command = command[:-1]

            else:
                try:
                    command += key.decode("utf-8")
                except:
                    pass
